<?php
session_start();
include('connection.php');
include('kawalan-admin.php');

// Semak login admin
if (!isset($_SESSION['noKP']) || $_SESSION['StatusPengguna'] !== 'admin') {
    header("location:login.php");
    exit;
}

if (!empty($_POST['nama_calon_baru']) && !empty($_POST['jawatan_calon_baru']) &&
    !empty($_POST['manifesto_calon_baru']) && isset($_FILES['gambar_calon'])) {

    $namaCalon  = mysqli_real_escape_string($condb, trim($_POST['nama_calon_baru']));
    $kodJawatan = (int)$_POST['jawatan_calon_baru'];
    $manifesto  = mysqli_real_escape_string($condb, trim($_POST['manifesto_calon_baru']));

    // ── Proses gambar ──────────────────────────────────────────────────
    $target_dir = "gambar/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

    $ext = strtolower(pathinfo($_FILES['gambar_calon']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "<script>alert('❌ Hanya fail gambar (JPG, JPEG, PNG, GIF) dibenarkan!'); window.history.back();</script>";
        exit;
    }

    if ($_FILES['gambar_calon']['size'] > 5 * 1024 * 1024) {
        echo "<script>alert('❌ Saiz fail terlalu besar! Maksimal 5MB'); window.history.back();</script>";
        exit;
    }

    $nama_fail = date("Ymd_His") . '_' . rand(1000, 9999) . '.' . $ext;
    $target_file = $target_dir . $nama_fail;

    if (!move_uploaded_file($_FILES['gambar_calon']['tmp_name'], $target_file)) {
        echo "<script>alert('❌ Gagal muat naik gambar. Pastikan folder gambar/ boleh ditulis.'); window.history.back();</script>";
        exit;
    }

    // ── Ambil nama jawatan untuk kemas kini JSON ───────────────────────
    $q_jawatan = mysqli_query($condb, "SELECT namaJawatan FROM jawatan WHERE kodJawatan=$kodJawatan");
    $row_jawatan = mysqli_fetch_array($q_jawatan);
    $namaJawatan = $row_jawatan ? $row_jawatan['namaJawatan'] : '';

    // ── Simpan ke DB ───────────────────────────────────────────────────
    $insert = "INSERT INTO calon (namaCalon, kodJawatan, gambar)
               VALUES ('\$namaCalon', \$kodJawatan, '\$nama_fail')";

    if (!mysqli_query($condb, $insert)) {
        // Rollback — buang gambar yang dah upload
        unlink($target_file);
        echo "<script>alert('❌ Pendaftaran Calon Gagal: " . addslashes(mysqli_error($condb)) . "'); window.history.back();</script>";
        exit;
    }

    $noCalon_baru = mysqli_insert_id($condb);

    // ── ✅ Kemas kini manifesto-data.json ─────────────────────────────
    $json_file = 'manifesto-data.json';
    $senarai   = [];

    if (file_exists($json_file)) {
        $senarai = json_decode(file_get_contents($json_file), true) ?? [];
    }

    // Cari ID tertinggi dalam JSON untuk jana ID baru
    $max_id = 0;
    foreach ($senarai as $item) {
        if (($item['id'] ?? 0) > $max_id) $max_id = $item['id'];
    }

    $senarai[] = [
        'id'        => $max_id + 1,
        'nama'      => $namaCalon,
        'gambar'    => $nama_fail,
        'jawatan'   => $namaJawatan,
        'manifesto' => $manifesto,
    ];

    file_put_contents($json_file, json_encode($senarai, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    echo "<script>
        alert('✅ Calon Berjaya Didaftarkan! Manifesto telah disimpan.');
        window.location.href='calon-senarai.php';
    </script>";

} else {
    echo "<script>alert('❌ Sila isi semua maklumat calon termasuk manifesto!'); window.history.back();</script>";
    exit;
}
?>
