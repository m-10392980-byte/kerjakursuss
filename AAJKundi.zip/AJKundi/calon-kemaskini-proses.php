<?php
session_start();
include('connection.php');
include('kawalan-admin.php');

if (!isset($_SESSION['noKP']) || $_SESSION['StatusPengguna'] !== 'admin') {
    header("location:login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: calon-senarai.php');
    exit;
}

$noCalon     = (int)$_POST['noCalon'];
$namaCalon   = mysqli_real_escape_string($condb, trim($_POST['nama_calon']));
$kodJawatan  = (int)$_POST['jawatan_calon'];
$gambar_lama = mysqli_real_escape_string($condb, $_POST['gambar_lama']);
$gambar_baru = $gambar_lama; // Default guna gambar lama

// Proses upload gambar baru (jika ada)
if (!empty($_FILES['gambar_calon']['name'])) {
    $target_dir = "gambar/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

    $ext = strtolower(pathinfo($_FILES['gambar_calon']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
        die("<script>alert('Format gambar tidak sah! Guna JPG, PNG atau GIF.'); window.history.back();</script>");
    }

    if ($_FILES['gambar_calon']['size'] > 5 * 1024 * 1024) {
        die("<script>alert('Saiz fail terlalu besar! Maksimal 5MB.'); window.history.back();</script>");
    }

    $gambar_baru  = date("Ymd_His") . '_' . rand(1000, 9999) . '.' . $ext;
    $target_file  = $target_dir . $gambar_baru;

    if (!move_uploaded_file($_FILES['gambar_calon']['tmp_name'], $target_file)) {
        die("<script>alert('Gagal muat naik gambar. Pastikan folder gambar/ boleh ditulis.'); window.history.back();</script>");
    }

    // Padam gambar lama (jika ada dan bukan default)
    if (!empty($gambar_lama) && $gambar_lama !== 'default.png' && file_exists($target_dir . $gambar_lama)) {
        unlink($target_dir . $gambar_lama);
    }
}

// Kemaskini DB
$update = "UPDATE calon SET 
           namaCalon  = '$namaCalon',
           kodJawatan = $kodJawatan,
           gambar     = '$gambar_baru'
           WHERE noCalon = $noCalon";

if (mysqli_query($condb, $update)) {
    echo "<script>alert('✅ Data calon berjaya dikemaskini!'); location.href='calon-senarai.php';</script>";
} else {
    echo "<script>alert('❌ Gagal kemaskini: " . addslashes(mysqli_error($condb)) . "'); window.history.back();</script>";
}
?>
