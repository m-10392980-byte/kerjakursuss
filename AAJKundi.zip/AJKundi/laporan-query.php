<?php
session_start();
include('header.php');
include('connection.php');
include('kawalan-admin.php');

if (!isset($_SESSION['noKP']) || $_SESSION['StatusPengguna'] !== 'admin') {
    header("location:login.php");
    exit;
}
?>

<head>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .query-container {
            max-width: 900px;
            margin: 40px auto;
            padding: 20px;
        }

        .query-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .query-header h1 {
            color: #7c3aed;
            font-size: 28px;
        }

        .query-form {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .query-form select {
            padding: 10px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 14px;
            min-width: 220px;
            cursor: pointer;
        }

        .query-form select:focus {
            outline: none;
            border-color: #7c3aed;
        }

        .btn-papar {
            padding: 10px 25px;
            background: #7c3aed;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-papar:hover {
            background: #6d28d9;
            transform: translateY(-2px);
        }

        .hasil-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }

        .hasil-table thead {
            background: #7c3aed;
            color: white;
        }

        .hasil-table th {
            padding: 14px 16px;
            text-align: left;
            font-weight: 600;
        }

        .hasil-table tbody tr {
            border-bottom: 1px solid #e2e8f0;
            transition: all 0.2s ease;
        }

        .hasil-table td { color: #1e293b; }

        .hasil-table tbody tr:hover {
            background: rgba(124, 58, 237, 0.05);
        }

        .hasil-table td {
            padding: 14px 16px;
        }

        .calon-gambar {
            width: 50px;
            height: 60px;
            object-fit: cover;
            border-radius: 6px;
            border: 2px solid #e2e8f0;
        }

        .undi-count {
            font-weight: bold;
            color: #7c3aed;
            font-size: 16px;
        }

        .empty-msg {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>

<div class="query-container">
    <div class="query-header">
        <h1>📊 Laporan Keputusan Undian</h1>
    </div>

    <!-- FORM QUERY -->
    <form method="POST" class="query-form">
        <select name="pilih_jawatan">
            <option value="">— Pilih Jawatan —</option>
            <option value="semua" <?php echo (isset($_POST['pilih_jawatan']) && $_POST['pilih_jawatan'] == 'semua') ? 'selected' : ''; ?>>
                KEPUTUSAN SEMUA JAWATAN
            </option>
            <?php
            $j_result = mysqli_query($condb, "SELECT * FROM jawatan ORDER BY kodJawatan");
            while ($j = mysqli_fetch_array($j_result)) {
                $selected = (isset($_POST['pilih_jawatan']) && $_POST['pilih_jawatan'] == $j['kodJawatan']) ? 'selected' : '';
                echo "<option value='{$j['kodJawatan']}' $selected>" . htmlspecialchars($j['namaJawatan']) . "</option>";
            }
            ?>
        </select>
        <button type="submit" class="btn-papar">Papar</button>
    </form>

    <!-- HASIL QUERY -->
    <?php if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['pilih_jawatan'])): ?>
    <table class="hasil-table">
        <thead>
            <tr>
                <th>Gambar</th>
                <th>Nama Calon</th>
                <th>Jawatan</th>
                <th>Bilangan Undian</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $pilih = $_POST['pilih_jawatan'];

        if ($pilih == 'semua') {
            $query = "SELECT calon.noCalon, calon.namaCalon, calon.gambar, jawatan.namaJawatan,
                             COUNT(undian.noCalon) as jumlah_vote
                      FROM calon
                      JOIN jawatan ON calon.kodJawatan = jawatan.kodJawatan
                      LEFT JOIN undian ON calon.noCalon = undian.noCalon
                      GROUP BY calon.noCalon
                      ORDER BY jawatan.kodJawatan, jumlah_vote DESC";
        } else {
            $kodJawatan = (int)$pilih;
            $query = "SELECT calon.noCalon, calon.namaCalon, calon.gambar, jawatan.namaJawatan,
                             COUNT(undian.noCalon) as jumlah_vote
                      FROM calon
                      JOIN jawatan ON calon.kodJawatan = jawatan.kodJawatan
                      LEFT JOIN undian ON calon.noCalon = undian.noCalon
                      WHERE calon.kodJawatan = $kodJawatan
                      GROUP BY calon.noCalon
                      ORDER BY jumlah_vote DESC";
        }

        $result = mysqli_query($condb, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_array($result)) {
                $gambar = !empty($row['gambar']) ? 'gambar/' . htmlspecialchars($row['gambar']) : 'gambar/default.png';
                echo "<tr>";
                echo "<td><img src='$gambar' class='calon-gambar' onerror=\"this.src='gambar/default.png'\"></td>";
                echo "<td>" . htmlspecialchars($row['namaCalon']) . "</td>";
                echo "<td>" . htmlspecialchars($row['namaJawatan']) . "</td>";
                echo "<td class='undi-count'>" . $row['jumlah_vote'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'><div class='empty-msg'>Tiada data dijumpai.</div></td></tr>";
        }
        ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include('footer.php'); ?>
