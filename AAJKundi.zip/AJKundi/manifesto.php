<?php
session_start();
include('header.php');
include('connection.php');

// ✅ Load calon & manifesto terus dari DB + JSON (gabungan)
// Ambil semua calon dari DB
$calon_query = mysqli_query($condb,
    "SELECT c.noCalon, c.namaCalon, c.gambar, j.namaJawatan
     FROM calon c
     JOIN jawatan j ON c.kodJawatan = j.kodJawatan
     
     ORDER BY j.kodJawatan, c.noCalon"
);

// Ambil manifesto dari JSON (indexed by nama)
$manifesto_map = [];
if (file_exists('manifesto-data.json')) {
    $json_data = json_decode(file_get_contents('manifesto-data.json'), true);
    if ($json_data) {
        foreach ($json_data as $item) {
            $manifesto_map[trim($item['nama'])] = $item['manifesto'] ?? '';
        }
    }
}

// Gabungkan data DB + manifesto JSON
$senarai_calon = [];
if ($calon_query) {
    while ($row = mysqli_fetch_assoc($calon_query)) {
        $nama = trim($row['namaCalon']);
        $row['manifesto'] = $manifesto_map[$nama] ?? 'Manifesto belum dikemaskini.';
        $senarai_calon[] = $row;
    }
}

// Ambil senarai jawatan unik untuk butang filter
$jawatan_unik = [];
foreach ($senarai_calon as $c) {
    if (!in_array($c['namaJawatan'], $jawatan_unik)) {
        $jawatan_unik[] = $c['namaJawatan'];
    }
}
?>

<section class="manifesto-container">
    <div class="manifesto-header">
        <h2 class="manifesto-title">Manifesto Calon AJK</h2>
        <p class="manifesto-subtitle">Visi dan Misi Calon untuk AJK Kadet Polis</p>
    </div>

    <!-- FILTER BUTTONS — dijana secara dinamik dari DB -->
    <div class="filter-section">
        <button class="filter-btn active" onclick="filterJawatan('Semua', this)">Semua</button>
        <?php foreach ($jawatan_unik as $j): ?>
        <button class="filter-btn" onclick="filterJawatan('<?php echo htmlspecialchars($j); ?>', this)">
            <?php echo htmlspecialchars($j); ?>
        </button>
        <?php endforeach; ?>
    </div>

    <!-- MANIFESTO GRID -->
    <div class="manifesto-grid" id="manifestoGrid">
        <?php if (!empty($senarai_calon)): ?>
            <?php foreach ($senarai_calon as $calon): ?>
            <div class="manifesto-card" data-jawatan="<?php echo htmlspecialchars($calon['namaJawatan']); ?>">

                <div class="manifesto-image-wrapper">
                    <img src="gambar/<?php echo htmlspecialchars($calon['gambar']); ?>"
                         alt="<?php echo htmlspecialchars($calon['namaCalon']); ?>"
                         class="manifesto-image"
                         onerror="this.src='gambar/default.png'">
                    <div class="jawatan-badge"><?php echo htmlspecialchars($calon['namaJawatan']); ?></div>
                </div>

                <div class="manifesto-content">
                    <h3 class="manifesto-nama"><?php echo htmlspecialchars($calon['namaCalon']); ?></h3>

                    <div class="manifesto-body">
                        <p class="manifesto-manifesto">
                            <strong>Manifesto:</strong> <?php echo htmlspecialchars($calon['manifesto']); ?>
                        </p>
                    </div>

                    <div class="manifesto-footer">
                        <a href="undi-calon.php" class="undi-btn">
                            🗳️ Undi Sekarang
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center; padding: 60px; color: #cbd5e1; grid-column: 1/-1;">
                <p style="font-size:18px;">Tiada calon didaftarkan lagi.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<style>
.manifesto-container { width: 100%; }

.manifesto-header {
    text-align: center;
    margin-bottom: 40px;
}

.manifesto-title {
    font-size: 40px;
    font-weight: 900;
    background: linear-gradient(135deg, #7c3aed, #ec4899, #06b6d4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 12px;
}

.manifesto-subtitle { font-size: 18px; color: #cbd5e1; }

.filter-section {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-bottom: 40px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 12px 24px;
    background: var(--glass);
    border: 1.5px solid rgba(124, 58, 237, 0.3);
    color: var(--text-light);
    border-radius: 20px;
    cursor: pointer;
    font-weight: 600;
    font-size: 14px;
    transition: var(--transition);
}

.filter-btn:hover,
.filter-btn.active {
    background: linear-gradient(135deg, #7c3aed, #06b6d4);
    border-color: transparent;
    color: white;
    box-shadow: 0 8px 16px rgba(124, 58, 237, 0.3);
}

.manifesto-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 24px;
    
}

/* @keyframes fadeIn {
    from { opacity: 0; } */

}

.manifesto-card {
    background: var(--glass);
    backdrop-filter: blur(10px) saturate(180%);
    border: 1px solid rgba(124, 58, 237, 0.2);
    border-radius: 20px;
    overflow: hidden;
    transition: var(--transition);
    display: flex;
    flex-direction: column;
}

.manifesto-card:hover {
    transform: translateY(-4px);
    border-color: #7c3aed;
    box-shadow: 0 20px 40px rgba(124, 58, 237, 0.2);
}

.manifesto-card.hidden { display: none; }

.manifesto-image-wrapper {
    position: relative;
    width: 100%;
    height: 280px;
    overflow: hidden;
    background: linear-gradient(135deg, rgba(124, 58, 237, 0.1), rgba(6, 182, 212, 0.1));
}

.manifesto-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: var(--transition);
}

.manifesto-card:hover .manifesto-image { transform: scale(1.1); }

.jawatan-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    background: linear-gradient(135deg, #7c3aed, #06b6d4);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.manifesto-content {
    padding: 24px;
    display: flex;
    flex-direction: column;
    flex: 1;
}

.manifesto-nama {
    font-size: 22px;
    font-weight: 800;
    background: linear-gradient(135deg, #7c3aed, #ec4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0 0 16px 0;
}

.manifesto-body { flex: 1; margin-bottom: 20px; }

.manifesto-manifesto {
    font-size: 14px;
    line-height: 1.6;
    color: #cbd5e1;
    margin: 0;
}

.manifesto-manifesto strong { color: #7c3aed; }

.manifesto-footer { display: flex; gap: 12px; }

.undi-btn {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 16px;
    background: linear-gradient(135deg, #7c3aed, #06b6d4);
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    transition: var(--transition);
}

.undi-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(124, 58, 237, 0.3);
}

@media (max-width: 768px) {
    .manifesto-title { font-size: 32px; }
    .manifesto-grid { grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 18px; }
    .manifesto-image-wrapper { height: 240px; }
    .filter-section { gap: 8px; }
    .filter-btn { padding: 10px 18px; font-size: 13px; }
}

@media (max-width: 480px) {
    .manifesto-title { font-size: 26px; }
    .manifesto-grid { grid-template-columns: 1fr; }
    .manifesto-image-wrapper { height: 200px; }
    .filter-section { flex-direction: column; }
    .filter-btn { width: 100%; }
}
</style>

<script>
function filterJawatan(jawatan, btn) {
    // Update butang aktif
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    // Tapis kad
    document.querySelectorAll('.manifesto-card').forEach(card => {
        const match = jawatan === 'Semua' || card.dataset.jawatan === jawatan;
        card.classList.toggle('hidden', !match);
    });
}
</script>

<?php include('footer.php'); ?>