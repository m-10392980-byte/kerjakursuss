<head>
<link rel="stylesheet" href="css/style.css">
</head>

<?php
include('header.php');
include('connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama       = mysqli_real_escape_string($condb, $_POST['namaPengguna']);
    $noKP       = mysqli_real_escape_string($condb, $_POST['noKP']);
    $katalaluan = mysqli_real_escape_string($condb, $_POST['katalaluan']);

    if (strlen($noKP) > 12) {
        die("<script>alert('No Kad Pengenalan anda melebihi 12 nombor.'); window.history.back();</script>");
    } elseif (strlen($noKP) < 12) {
        die("<script>alert('No Kad Pengenalan anda tidak mencukupi 12 nombor.'); window.history.back();</script>");
    } elseif (!ctype_digit($noKP)) {
        die("<script>alert('No Kad Pengenalan mestilah nombor sahaja.'); window.history.back();</script>");
    }

    $semak = mysqli_query($condb, "SELECT noKP FROM pengguna WHERE noKP='$noKP'");
    if (mysqli_num_rows($semak) == 1) {
        die("<script>alert('No Kad Pengenalan telah digunakan.'); window.history.back();</script>");
    }

    $query = "INSERT INTO pengguna (noKP, namaPengguna, katalaluan, StatusPengguna) VALUES ('$noKP', '$nama', '$katalaluan', 'pengundi')";
    if (mysqli_query($condb, $query)) {
        echo "<script>alert('Anda Telah Berjaya Mendaftar!'); location.href='login.php';</script>";
    } else {
        echo "<script>alert('Pendaftaran Gagal. Sila Cuba Lagi.');</script>";
    }
}
?>

<form class="form" method="POST" action="" onsubmit="return validateForm()">
    <p class="title">Daftar Pengguna Baru</p>
    <p class="message">Sila Masukkan Maklumat Yang Diperlukan Di Bawah</p>

    <label class="field">
        <input class="finput" type="text" name="noKP" id="noKP" required placeholder=" ">
        <span>No Kad Pengenalan (12 digit)</span>
    </label>

    <label class="field">
        <input class="finput" type="text" name="namaPengguna" required placeholder=" ">
        <span>Nama</span>
    </label>

    <label class="field">
        <input class="finput" type="password" name="katalaluan" required placeholder=" ">
        <span>Katalaluan</span>
    </label>

    <button class="btn-primary" type="submit">Daftar</button>
</form>

<script>
function validateForm() {
    var noKP = document.getElementById('noKP').value;
    if (noKP.length > 12) { alert('No Kad Pengenalan anda melebihi 12 nombor.'); return false; }
    if (noKP.length < 12) { alert('No Kad Pengenalan anda tidak mencukupi 12 nombor.'); return false; }
    return true;
}
</script>

<?php include('footer.php'); ?>