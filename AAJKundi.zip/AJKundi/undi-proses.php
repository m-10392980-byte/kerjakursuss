<?php
session_start();
include('connection.php');

// Check if user is logged in
if (empty($_SESSION['StatusPengguna']) || $_SESSION['StatusPengguna'] != 'pengundi') {
    header('Location: login.php');
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: undi-calon.php');
    exit;
}

$noKP = $_SESSION['noKP'];
$positions_order = ['Pengerusi', 'Timbalan Pengerusi', 'Setiausaha', 'Bendahari'];

// Validate that all positions have votes
$votes = [];
$valid = true;

foreach ($positions_order as $position) {
    $fieldName = 'jawatan_' . str_replace(' ', '_', $position);

    if (!isset($_POST[$fieldName]) || empty($_POST[$fieldName])) {
        $valid = false;
        break;
    }

    $votes[$position] = (int)$_POST[$fieldName];
}

if (!$valid) {
    $_SESSION['undi_error'] = 'Sila pilih satu calon untuk setiap jawatan.';
    header('Location: undi-calon.php');
    exit;
}

// Check if user already voted
$check_vote = mysqli_query($condb, "SELECT * FROM undian WHERE noKP='" . mysqli_real_escape_string($condb, $noKP) . "'");

if (!$check_vote) {
    $_SESSION['undi_error'] = 'Database error. Sila cuba lagi.';
    header('Location: undi-calon.php');
    exit;
}

if (mysqli_num_rows($check_vote) > 0) {
    // Already voted — redirect terus ke hasil
    header('Location: hasil-undi.php');
    exit;
}

// Insert votes into database
$success = 0;
$fail = 0;

foreach ($votes as $position => $calon_id) {
    $insert_query = "INSERT INTO undian (noKP, noCalon) 
                     VALUES ('" . mysqli_real_escape_string($condb, $noKP) . "', $calon_id)";

    if (mysqli_query($condb, $insert_query)) {
        $success++;
    } else {
        $fail++;
    }
}

if ($fail == 0) {
    // ✅ Undi berjaya — set session dan redirect ke hasil-undi.php
    $_SESSION['undi_berjaya'] = true;
    $_SESSION['undi_jawatan_count'] = $success;
    header('Location: hasil-undi.php');
    exit;
} else {
    $_SESSION['undi_error'] = "Ralat semasa menyimpan. Berjaya: $success | Gagal: $fail. Sila hubungi pentadbir.";
    header('Location: undi-calon.php');
    exit;
}
?>