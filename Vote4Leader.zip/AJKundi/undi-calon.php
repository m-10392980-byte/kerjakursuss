<?php
session_start();
include('header.php');

// Check if user is logged in
if (empty($_SESSION['jenisPengguna']) || $_SESSION['jenisPengguna'] != 'pengundi') {
    header('Location: login.php');
    exit;
}

// Load manifesto data
$json = file_get_contents('manifesto-data.json');
$manifestos = json_decode($json, true);

// Get candidate ID from URL
$candidateId = isset($_GET['id']) ? (int)$_GET['id'] : null;
$selectedCandidate = null;

if ($candidateId) {
    foreach ($manifestos as $calon) {
        if ($calon['id'] == $candidateId) {
            $selectedCandidate = $calon;
            break;
        }
    }
}
?>

<section class="voting-container">
    <div class="voting-header">
        <h2 class="voting-title">Undi Calon AJK</h2>
        <p class="voting-subtitle">Pilih calon pilihan anda dengan bijak</p>
    </div>

    <?php if ($selectedCandidate): ?>
    <!-- VOTING FOR SPECIFIC CANDIDATE -->
    <div class="voting-card">
        <div class="candidate-preview">
            <img src="gambar/<?php echo htmlspecialchars($selectedCandidate['gambar']); ?>" 
                 alt="<?php echo htmlspecialchars($selectedCandidate['nama']); ?>"
                 class="candidate-image">
        </div>

        <div class="voting-details">
            <h3 class="candidate-title"><?php echo htmlspecialchars($selectedCandidate['nama']); ?></h3>
            <div class="candidate-jawatan">
                <strong>Jawatan:</strong> 
                <span class="jawatan-tag"><?php echo htmlspecialchars($selectedCandidate['jawatan']); ?></span>
            </div>
            <div class="candidate-manifesto">
                <strong>Manifesto:</strong>
                <p><?php echo htmlspecialchars($selectedCandidate['manifesto']); ?></p>
            </div>

            <form method="POST" action="undi-proses.php" class="voting-form">
                <input type="hidden" name="calon_id" value="<?php echo $selectedCandidate['id']; ?>">
                <input type="hidden" name="calon_nama" value="<?php echo htmlspecialchars($selectedCandidate['nama']); ?>">
                
                <div class="confirm-section">
                    <p class="confirm-text">Anda pasti ingin mengundi calon ini?</p>
                    <div class="button-group">
                        <a href="manifesto.php" class="btn-cancel">← Kembali</a>
                        <button type="submit" class="btn-confirm">
                            <i class="fas fa-check-circle"></i> Sahkan Undi
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php else: ?>
    <!-- SHOW ALL CANDIDATES FOR VOTING -->
    <div class="candidates-grid">
        <?php foreach ($manifestos as $calon): ?>
        <div class="candidate-card">
            <div class="candidate-image-wrapper">
                <img src="gambar/<?php echo htmlspecialchars($calon['gambar']); ?>" 
                     alt="<?php echo htmlspecialchars($calon['nama']); ?>"
                     class="candidate-thumb">
                <div class="candidate-jawatan-badge"><?php echo htmlspecialchars($calon['jawatan']); ?></div>
            </div>

            <div class="candidate-info">
                <h4 class="candidate-name"><?php echo htmlspecialchars($calon['nama']); ?></h4>
                <a href="undi-calon.php?id=<?php echo $calon['id']; ?>" class="btn-vote">
                    Undi Sekarang
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php endif; ?>
</section>

<?php include('footer.php'); ?>
    </div>
</main>

<style>
/* ============ VOTING SECTION ============ */
.voting-container {
    width: 100%;
    max-width: 900px;
    margin: 0 auto;
}

.voting-header {
    text-align: center;
    margin-bottom: 40px;
}

.voting-title {
    font-size: 40px;
    font-weight: 900;
    background: linear-gradient(135deg, #7c3aed, #ec4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 12px;
}

.voting-subtitle {
    font-size: 16px;
    color: #cbd5e1;
}

/* VOTING CARD (SINGLE CANDIDATE) */
.voting-card {
    background: var(--glass);
    backdrop-filter: blur(20px) saturate(200%);
    border: 1px solid rgba(124, 58, 237, 0.3);
    border-radius: 24px;
    padding: 40px;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 40px;
    align-items: center;
    box-shadow: 0 16px 48px rgba(124, 58, 237, 0.15);
}

.candidate-preview {
    display: flex;
    align-items: center;
    justify-content: center;
}

.candidate-image {
    width: 100%;
    max-width: 300px;
    height: auto;
    border-radius: 20px;
    border: 2px solid rgba(124, 58, 237, 0.3);
    box-shadow: 0 12px 32px rgba(124, 58, 237, 0.2);
}

.voting-details {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.candidate-title {
    font-size: 32px;
    font-weight: 900;
    background: linear-gradient(135deg, #7c3aed, #06b6d4);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0;
}

.candidate-jawatan {
    padding: 16px;
    background: rgba(124, 58, 237, 0.1);
    border: 1px solid rgba(124, 58, 237, 0.2);
    border-radius: 12px;
    font-size: 16px;
    color: var(--text-light);
}

.jawatan-tag {
    background: linear-gradient(135deg, #7c3aed, #06b6d4);
    color: white;
    padding: 6px 12px;
    border-radius: 8px;
    font-weight: 700;
    font-size: 14px;
    margin-left: 8px;
}

.candidate-manifesto {
    padding: 16px;
    background: rgba(6, 182, 212, 0.1);
    border: 1px solid rgba(6, 182, 212, 0.2);
    border-radius: 12px;
    font-size: 15px;
    color: var(--text-light);
    line-height: 1.6;
}

.candidate-manifesto p {
    margin: 8px 0 0 0;
}

/* CONFIRM SECTION */
.confirm-section {
    padding: 20px;
    background: rgba(236, 72, 153, 0.1);
    border: 2px solid rgba(236, 72, 153, 0.3);
    border-radius: 12px;
    margin-top: 20px;
}

.confirm-text {
    text-align: center;
    font-size: 16px;
    color: var(--text-light);
    margin-bottom: 20px;
    font-weight: 600;
}

.button-group {
    display: flex;
    gap: 12px;
}

.btn-cancel,
.btn-confirm {
    flex: 1;
    padding: 14px 20px;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    font-size: 16px;
    cursor: pointer;
    transition: var(--transition);
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.btn-cancel {
    background: var(--glass);
    border: 1px solid rgba(124, 58, 237, 0.2);
    color: var(--text-light);
}

.btn-cancel:hover {
    border-color: #7c3aed;
    background: rgba(124, 58, 237, 0.1);
}

.btn-confirm {
    background: linear-gradient(135deg, #10b981, #06b6d4);
    color: white;
    box-shadow: 0 8px 20px rgba(16, 185, 129, 0.3);
}

.btn-confirm:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 28px rgba(16, 185, 129, 0.4);
}

/* CANDIDATES GRID (NO SELECTION) */
.candidates-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 20px;
}

.candidate-card {
    background: var(--glass);
    backdrop-filter: blur(10px) saturate(180%);
    border: 1px solid rgba(124, 58, 237, 0.2);
    border-radius: 16px;
    overflow: hidden;
    transition: var(--transition);
    display: flex;
    flex-direction: column;
}

.candidate-card:hover {
    transform: translateY(-8px);
    border-color: #7c3aed;
    box-shadow: 0 12px 32px rgba(124, 58, 237, 0.15);
}

.candidate-image-wrapper {
    position: relative;
    width: 100%;
    height: 220px;
    overflow: hidden;
    background: linear-gradient(135deg, rgba(124, 58, 237, 0.1), rgba(6, 182, 212, 0.1));
}

.candidate-thumb {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: var(--transition);
}

.candidate-card:hover .candidate-thumb {
    transform: scale(1.1);
}

.candidate-jawatan-badge {
    position: absolute;
    bottom: 12px;
    left: 12px;
    background: rgba(0, 0, 0, 0.6);
    color: white;
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
}

.candidate-info {
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.candidate-name {
    font-size: 16px;
    font-weight: 800;
    color: var(--text-light);
    margin: 0;
}

.btn-vote {
    padding: 10px 16px;
    background: linear-gradient(135deg, #7c3aed, #06b6d4);
    color: white;
    text-decoration: none;
    border-radius: 8px;
    font-weight: 600;
    font-size: 13px;
    text-align: center;
    transition: var(--transition);
    border: none;
    cursor: pointer;
}

.btn-vote:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(124, 58, 237, 0.3);
}

/* RESPONSIVE */
@media (max-width: 1024px) {
    .voting-card {
        grid-template-columns: 1fr;
        padding: 30px;
        gap: 30px;
    }

    .candidate-image {
        max-width: 250px;
    }

    .voting-title {
        font-size: 32px;
    }
}

@media (max-width: 768px) {
    .voting-card {
        padding: 24px;
    }

    .candidates-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 16px;
    }

    .voting-title {
        font-size: 28px;
    }

    .candidate-title {
        font-size: 24px;
    }

    .button-group {
        flex-direction: column;
    }
}

@media (max-width: 480px) {
    .voting-card {
        padding: 20px;
    }

    .candidates-grid {
        grid-template-columns: 1fr;
    }

    .voting-title {
        font-size: 24px;
    }

    .candidate-title {
        font-size: 20px;
    }

    .candidate-image {
        max-width: 100%;
    }

    .candidate-image-wrapper {
        height: 180px;
    }
}
<form method="POST" action="undi-proses.php" class="voting-form">
</style>
</body>
</html>